import numpy as np
import matplotlib.pyplot as plt

def create_histogram(data):
    
    # Extract individual components
    frequency_labels = [entry[0] for entry in data]
    normal_percentages = [entry[1] for entry in data]
    c_section_percentages = [entry[2] for entry in data]

    # Bar settings
    bar_width = 0.35
    indices = range(len(frequency_labels))
    offset = [i + bar_width for i in indices]

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.bar(indices, normal_percentages, width=bar_width, label="Normal Delivery %", color='skyblue')
    plt.bar(offset, c_section_percentages, width=bar_width, label="C-Section Delivery %", color='salmon')
    plt.xlabel("Birth Frequency")
    plt.ylabel("Delivery Percentage")
    plt.xticks([i + bar_width / 2 for i in indices], frequency_labels)
    plt.title("Delivery Methods by Birth Frequency")
    plt.legend()
    plt.show()

def create_dual_donut_chart(data, title="Delivery Methods by Residence", figsize=(8, 5)):
    # Reshape data into nested format
    structured = [
        (
            residence.title(), 
            [("Normal", normal_pct), ("C-Section", c_section_pct)]
        )
        for residence, normal_pct, c_section_pct in data
    ]
    fig, axs = plt.subplots(1, len(structured), figsize=figsize)
    fig.suptitle(title, fontsize=14)
    # Ensure axs is iterable even if there's one chart
    if len(structured) == 1:
        axs = [axs]
    
    for i, (group_label, segments) in enumerate(structured):
        labels, sizes = zip(*segments)
        colors = plt.cm.Set2.colors[:len(sizes)]
        wedges, _ = axs[i].pie(
            sizes,
            labels=None,
            colors=colors,
            startangle=90,
            wedgeprops=dict(width=0.4)
        )
        # Annotate and label
        axs[i].text(0, 0, group_label, ha='center', va='center', fontsize=12)
        axs[i].set_title(group_label)
        axs[i].legend(wedges, labels, loc='upper right', bbox_to_anchor=(1, 0.9))
    
    plt.tight_layout()
    plt.show()

def create_dual_pie_chart(data, figsize=(10, 5), title="Stay Duration by Delivery Type"):
    labels = [row[0] for row in data]
    normal_values = [row[1] for row in data]
    csection_values = [row[2] for row in data]
    
    colors = plt.cm.Pastel1.colors[:len(labels)]
    explode = [0.04] * len(labels)

    fig, axs = plt.subplots(1, 2, figsize=figsize)
    fig.suptitle(title, fontsize=14)

    # Normal Delivery Pie
    axs[0].pie(
        normal_values,
        labels=labels,
        autopct="%1.1f%%",
        startangle=140,
        explode=explode,
        colors=colors,
        wedgeprops=dict(edgecolor='gray')
    )
    axs[0].set_title("Normal Deliveries")
    axs[0].axis("equal")

    # C-Section Delivery Pie
    axs[1].pie(
        csection_values,
        labels=labels,
        autopct="%1.1f%%",
        startangle=140,
        explode=explode,
        colors=colors,
        wedgeprops=dict(edgecolor='gray')
    )
    axs[1].set_title("C-Section Deliveries")
    axs[1].axis("equal")

    plt.tight_layout()
    plt.show()


def create_side_by_side_bar_chart(data, category_label="Category", value_labels=("% Normal delivery", "% C Section delivery"),
                                   title="Side-by-Side Bar Chart", xlabel=None, ylabel="Percentage", figsize=(10, 6)):
    categories = [row[0] for row in data]
    values1 = [row[1] for row in data]
    values2 = [row[2] for row in data]

    x = np.arange(len(categories))  # label locations
    width = 0.35  # width of the bars

    fig, ax = plt.subplots(figsize=figsize)
    bars1 = ax.bar(x - width/2, values1, width, label=value_labels[0], color="#66c2a5")
    bars2 = ax.bar(x + width/2, values2, width, label=value_labels[1], color="#fc8d62")

    # Text labels and style
    ax.set_title(title)
    ax.set_xlabel(xlabel or category_label)
    ax.set_ylabel(ylabel)
    ax.set_xticks(x)
    ax.set_xticklabels(categories, rotation=30)
    ax.legend()

    # Annotate bars with their height
    for bars in (bars1, bars2):
        for bar in bars:
            height = bar.get_height()
            ax.annotate(f"{height:.1f}",
                        xy=(bar.get_x() + bar.get_width()/2, height),
                        xytext=(0, 3),
                        textcoords="offset points",
                        ha='center', va='bottom')

    plt.tight_layout()
    plt.show()