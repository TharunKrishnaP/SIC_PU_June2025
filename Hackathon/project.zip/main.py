from flask import Flask, render_template, request
from db_operations import *
from visuals import *

app = Flask(__name__)

ops_dictionary = {
    "1": ("birth_order_criteria", create_histogram),
    "2": ("residence_criteria", create_dual_donut_chart),
    "3": ("stay_duration_criteria_public", create_dual_pie_chart),
    "4": ("stay_duration_criteria_private", create_dual_pie_chart),
    "5": ("wealth_quintile_criteria", create_side_by_side_bar_chart)
}

def read_description(filename):
    try:
        with open(f"descriptions/{filename}.txt", "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return "Description not available for this criteria."

@app.route("/", methods=["GET", "POST"])
def home():
    chart_path, description = None, None
    if request.method == "POST":
        choice = request.form.get("choice")
        if choice in ops_dictionary:
            table_name, plot_func = ops_dictionary[choice]
            table_data = read_table(table_name)
            chart_path = plot_func(table_data)
            description = read_description(table_name)
    return render_template("index.html", chart_path=chart_path, description=description)

if __name__ == "__main__":
    app.run(debug=True)